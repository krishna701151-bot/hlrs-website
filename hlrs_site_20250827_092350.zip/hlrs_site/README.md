# HLRS Business Static Site (Fresh Build)

## Quick Edit
- Brand text & email already set for HLRS.
- Edit sections in `index.html` as needed.

## Run Locally
Open `index.html` in your browser.

## Host for Free (GitHub Pages)
- Create a public repo, upload these files to the root, and enable Pages from `main / (root)`.
